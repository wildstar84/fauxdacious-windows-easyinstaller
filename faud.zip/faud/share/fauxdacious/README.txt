NOTE:  You NO LONGER NEED to uninstall Audacious and all audacious packages, 
ie. libaudcore, libaudgui, libaudtag, etc.  before installing Fauxdacious!
Both programs can now happily reside on the same system and root path.

How to build:

(For additional general info, see:  http://redmine.audacious-media-player.org/boards/1/topics/788?r=1762#message-1762 - 
Building Audacious)

(For building on M$-Windows systems, see:  http://phoenixcomm.net/~jturner/fauxdacious_buildnotes.htm

Install the following Dependencies:

sudo apt-get install git automake build-essential libasound2-dev \
libavformat-dev libbinio-dev libbs2b-dev libcddb2-dev libcdio-cdda-dev \
libcue-dev libcurl4-gnutls-dev libdbus-glib-1-dev libfaad-dev libflac-dev \
libfluidsynth-dev libgl1-mesa-dev-lts-utopic libgtk2.0-dev libguess-dev \
libjack-jackd2-dev liblircclient-dev libmms-dev libmodplug-dev libmp3lame-dev \
libmpg123-dev libneon27-gnutls-dev libnotify-dev libpulse-dev \
libsamplerate0-dev libsdl2-dev libsidplayfp-dev libsndfile1-dev libsoxr-dev \
libvorbis-dev libwavpack-dev libxml2-dev libswscale-dev

Download and install from Github:

	cd /tmp
	mkdir fauxdacious
	mkdir fauxdacious-plugins
	git clone --single-branch git://github.com/wildstar84/fauxdacious.git fauxdacious
	git clone --single-branch git://github.com/wildstar84/fauxdacious-plugins.git fauxdacious-plugins

Build Fauxdacious:

	cd fauxdacious
	./autogen.sh
	./configure --prefix=/usr/local [--enable-qt] --with-buildstamp=Fauxdacious
	make
	(sudo) make install

	sudo ldconfig

Build Fauxdacious Plugins:

	cd ../fauxdacious-plugins
	./autogen.sh
	./configure --prefix=/usr/local [--enable-qt]
	make
	(sudo) make install

	sudo update-desktop-database
	sudo update-icon-caches /usr/share/icons/hicolor

Optional (copy your existing Audacious profile to Fauxdacious):  

	cd ~/.config; mkdir fauxdacious; cp -R audacious/. fauxdacious
	# This copies your previous default Audacious instance profile to the new
	# (Fauxdacious) location.

Now run fauxdacious:

	fauxdacious &

Fauxdacious should now start up.  Enjoy Fauxdacious!
Be sure to read the "FAQ" file and the GIT commits for the latest Fauxdacious 
features, fixes, changes, and how to configure to take best advantage of them!

FAQ:  https://wildstar84.github.io/fauxdacious/FAQ.htm
